/**
 * Zalo Extension ↔ Web Bridge
 * Inject trên localhost:3000 (và các domain frontend cần) để web page có thể
 * giao tiếp với background service worker qua window.postMessage.
 *
 * Flow:
 *   web → window.postMessage({ __zaloExt, type, requestId, data })
 *   bridge (content script) nhận → chrome.runtime.sendMessage tới background
 *   background xử lý → response về bridge → bridge postMessage lại web
 *
 * Đồng thời set window.__zaloExtensionAvailable = true để web detect nhanh.
 */

(function () {
  "use strict";

  // Set flag ngay để web detect extension có cài
  try {
    window.__zaloExtensionAvailable = true;
  } catch (e) {}

  const BRIDGE_TAG = "__zaloExtBridge";

  if (window[BRIDGE_TAG]) return; // tránh inject 2 lần
  window[BRIDGE_TAG] = true;

  // ─── Helpers ─────────────────────────────────────────────────────────

  function postToWeb(payload) {
    try {
      window.postMessage({ __zaloExt: true, ...payload }, "*");
    } catch (e) {
      console.warn("[Zalo Ext Bridge] postMessage to web failed:", e);
    }
  }

  function respond(requestId, success, dataOrError) {
    if (success) {
      postToWeb({ type: "RESPONSE", requestId, success: true, data: dataOrError });
    } else {
      postToWeb({
        type: "RESPONSE",
        requestId,
        success: false,
        error: typeof dataOrError === "string" ? dataOrError : (dataOrError?.message || "Unknown error"),
      });
    }
  }

  // ─── Message handlers ────────────────────────────────────────────────

  async function handlePing(requestId) {
    respond(requestId, true, { installed: true, version: "1.1.1" });
  }

  async function handleGetCookies(requestId) {
    try {
      const cookies = await chrome.runtime.sendMessage({ type: "EXTRACT_COOKIES_ONLY" });
      respond(requestId, true, cookies);
    } catch (e) {
      respond(requestId, false, e.message || String(e));
    }
  }

  async function handleCheckLogin(requestId) {
    try {
      const cookies = await chrome.runtime.sendMessage({ type: "EXTRACT_COOKIES_ONLY" });
      const keys = (cookies?.cookies || cookies || []).map((c) => c.key || c.name);
      const required = ["zpw_sek", "zpsid"];
      const missing = required.filter((k) => !keys.includes(k));
      respond(requestId, true, {
        is_logged_in: missing.length === 0 && keys.length > 0,
        cookies_count: keys.length,
        missing,
        keys,
      });
    } catch (e) {
      respond(requestId, false, e.message || String(e));
    }
  }

  async function handleImportSession(requestId, data) {
    /**
     * Relay IMPORT_ZALO_SESSION to background.js which will:
     *  1. Open Zalo Web tab
     *  2. Wait for login confirmation (polling content-script)
     *  3. Extract cookies
     *  4. POST to data.backend_url (zalo-bridge) with data.owner_id as inboxId
     *  5. Return { success, zaloId, backend }
     *
     * Timeout here set slightly higher than login_timeout_ms in data to let
     * background handle its own deadline first.
     */
    try {
      const timeoutMs = (data?.login_timeout_ms || 60000) + 15000;
      const result = await Promise.race([
        chrome.runtime.sendMessage({
          type: "IMPORT_ZALO_SESSION",
          data: data || {},
        }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Bridge timeout after ${timeoutMs}ms`)), timeoutMs)
        ),
      ]);
      if (result && result.success) {
        respond(requestId, true, result);
      } else {
        respond(requestId, false, result?.error || "Import failed");
      }
    } catch (e) {
      respond(requestId, false, e.message || String(e));
    }
  }

  // ─── Message listener ────────────────────────────────────────────────

  window.addEventListener("message", (event) => {
    if (event.source !== window) return; // bỏ qua cross-origin postMessage
    const msg = event.data;
    if (!msg || msg.__zaloExt !== true) return;
    // Bỏ qua message do chính bridge gửi ra (để tránh loop)
    if (msg.type === "RESPONSE" || msg.type === "STATE_UPDATE") return;
    if (!msg.requestId) return;

    switch (msg.type) {
      case "PING":
        handlePing(msg.requestId);
        break;
      case "GET_ZALO_COOKIES":
        handleGetCookies(msg.requestId);
        break;
      case "CHECK_ZALO_LOGIN":
        handleCheckLogin(msg.requestId);
        break;
      case "IMPORT_ZALO_SESSION":
        handleImportSession(msg.requestId, msg.data);
        break;
      default:
        respond(msg.requestId, false, `Unknown bridge message type: ${msg.type}`);
    }
  });

  console.log("[Zalo Ext Bridge] Loaded on", location.href);
})();
